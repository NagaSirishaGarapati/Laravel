<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel Crud</title>
        
        <!-- Bootstrap -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
       	<nav class="navbar navbar-default navbar-ststic-top">
       		<div class="container">
       			<div class="navbar-header">
       				<a class="navbar-brand" href="{{route('post.index')}}">Laravel Example</a>
       			</div>
       		</div>
       	</nav>
       	<div class="container">
       		@yield('content')
       	</div>
       	{{-- ajax Form Add --}}
       	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
       	<script type="text/javascript">
       		$(document).on('click','.create-modal',function(){
       			$('#create').modal('show');
       			$('.form-horizontal').show();
       			$('.modal-title').text('Add Post');
       		});
       		//function Add(Save)
       		$('#add').click(function(){
       			$.ajax({
       				type: 'POST',
       				url: 'addPost',
       				data: {
       					'_token':$('input[name=_token]').val(),
       					'title':$('input[name=title]').val(),
       					'body':$('input[name=body]').val(),
       				},
       				success: function(data){
       					if(data.errors){
       						$('.error').removeClass('hidden');
       						$('.error').text(data.errors.title);
       						$('.error').text(data.errors.body);
       					}
       					else{
       						$('.error').remove();
       						$('#table').append("<tr class='post" + data.id + "'>"+
       					 	"<td>" + data.id + "</td>"+
       					 	"<td>" + data.title +"</td>"+
       					 	"<td>" + data.body + "</td>"+
       					 	"<td>" + data.created_at + "</td>"+
       					 	"<td>"+
       					 	"<a class='show-modal btn btn-info btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='fa fa-eye'></i>"+
       					 	"</a>"+
       					 	"<a href='#' class='edit-modal btn btn-warning btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='glyphicon glyphicon-pencil'></i>"+
       					 	"</a>"+
       					 	"<a href='#' class='delete-modal btn btn-danger btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='glyphicon glyphicon-trash'></i>"+
       					 	"</a></td>"+
       					 "</tr>");
       					}
       				},
       			});
       			$('#title').val('');
       			$('#body').val('');
       		});
       		
       	//show function
       	$(document).on('click', '.show-modal', function(){
       		
       		$('.modal-title').text('Show Post');
       		
       		$('#showTt').text($(this).data('title'));
       		$('#showBd').text($(this).data('body'));
       		$('#show').modal('show');
       	});
       	
       	//Edit Function
       	$(document).on('click', '.edit-modal', function(){
       		$('#footer_action_button').text("Update Post");
       		$('#footer_action_button').addClass('glyphicon-check');
       		$('#footer_action_button').removeClass('glyphicon-trash');
       		$('.actionBtn').addClass('btn-success');
       		$('.actionBtn').removeClass('btn-danger');
       		$('.actionBtn').addClass('edit');
       		$('.modal-title').text('Post Edit');
       		$('.deleteContent').hide();
       		$('.form-horizontal').show();
       		$('#fid').val($(this).data('id'));
       		$('#t').val($(this).data('title'));
       		$('#b').val($(this).data('body'));
       		$('#myModal').modal('show');
       	});
       	
       	$('.modal-footer').on('click','.edit', function(){
       		$.ajax({
       			type: 'POST',
       			url: 'editPost',
       			data: {
       				'_token': $('input[name=_token]').val(),
       				'id': $('#fid').val(),
       				'title': $('#t').val(),
       				'body': $('#b').val()
       			},
       			success: function(data){
       				$('.post' + data.id).replaceWith(" "+
       						"<tr class='post" + data.id + "'>"+
       					 	"<td>" + data.id + "</td>"+
       					 	"<td>" + data.title +"</td>"+
       					 	"<td>" + data.body + "</td>"+
       					 	"<td>" + data.created_at + "</td>"+
       					 	"<td>"+
       					 	"<a class='show-modal btn btn-info btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='fa fa-eye'></i>"+
       					 	"</a>"+
       					 	"<a href='#' class='edit-modal btn btn-warning btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='glyphicon glyphicon-pencil'></i>"+
       					 	"</a>"+
       					 	"<a href='#' class='delete-modal btn btn-danger btn-sm' data-id='" + data.id + "' data-title='" + data.title + "' data-body='" + data.body + "'>"+
       					 	"<i class='glyphicon glyphicon-trash'></i>"+
       					 	"</a></td>"+
       					 "</tr>");
       			}
       		});
       	});
       	
       	//Delete function
       	$(document).on('click','.delete-modal', function(){
       		$('#footer_action_button').text("Delete");
       		$('#footer_action_button').removeClass('glyphicon-check');
       		$('#footer_action_button').addClass('glyphicon-trash');
       		$('.actionBtn').removeClass('btn-success');
       		$('.actionBtn').addClass('btn-danger');
       		$('.actionBtn').addClass('delete');
       		$('.modal-title').text('Delete Post');
       		$('.id').text($(this).data('id'));
       		$('.deleteContent').show();
       		$('.form-horizontal').hide();
       		$('.title').html($(this).data('title'));
       		$('#myModal').modal('show');
       	});
       	
       	$('.modal-footer').on('click','.delete', function(){
       		$.ajax({
       			type:'POST',
       			url:'deletePost',
       			data: {
       				'_token': $('input[name=_token]').val(),
       				'id':$('.id').text()
       			},
       			success: function(data){
       				$('.post'+$('.id'.text()).remove());
       			}
       		});
       	});
       	</script>
       	
    </body>
</html>
